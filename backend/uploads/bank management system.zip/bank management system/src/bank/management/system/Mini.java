package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.sql.ResultSet;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Mini extends JFrame implements ActionListener{
    String pin;
    JButton button1;

    Mini(String pin){
        this.pin=pin;
        getContentPane().setBackground(new Color(255,204,204));
        setSize(400,600);
        setLocation(20,20);
        setLayout(null);

        JLabel label1=new JLabel();
        label1.setBounds(20,140,400,200);
        add(label1);

        JLabel label2=new JLabel("Roopa");
        label2.setFont(new Font("System",Font.BOLD,15));
        label2.setBounds(150,20,200,20);
        add(label2);

        JLabel label3 =new JLabel();
        label3.setBounds(20,80,300,20);
        add(label3);

        JLabel label4=new JLabel();
        label4.setBounds(20,400,300,20);
        add(label4);
        
        try{
            Com c=new Com();
            ResultSet rs=c.statement.executeQuery("select * from login where pin='"+pin+"'");
            while(rs.next()){
                label3.setText("Card Number:" +rs.getString("card_number").substring(0,4)+"XXXXXXXXXXXX"+rs.getString("card_number").substring(12));
            }
        }catch(Exception e){
            e.printStackTrace();
        }

        try{
            int balance=0;
            Com c= new Com();
            ResultSet resultSet=c.statement.executeQuery("select * from bank where pin='"+pin+"'");
            while(resultSet.next()){
                label1.setText(label1.getText()+"<html>"+resultSet.getString("date")+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+resultSet.getString("type")+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+resultSet.getString("amount")+"<br><br><html>");
                if(resultSet.getString("type").equals("Deposit")){
                    balance += Integer.parseInt(resultSet.getString("amount"));
                }else{
                    balance -= Integer.parseInt(resultSet.getString("amount"));
                }
            }
            label4.setText("your total Balance is Rs."+balance);
        }catch(Exception e){
            e.printStackTrace();
        }

        button1 =new JButton("Exit");
        button1.setBounds(20,500,100,25);
        button1.addActionListener(this);
        button1.setBackground(Color.BLACK);
        button1.setForeground(Color.WHITE);
        add(button1);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e){
        setVisible(false);
    }
    public static void main(String[] args){
        new Mini("");
    }
}
