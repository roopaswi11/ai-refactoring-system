package bank.management.system;
import java.sql.*;

public class Com {
    Connection connection;
    Statement statement;
    public Com(){
        try{
            connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/banksystem","root","roopa");
            statement= connection.createStatement();

        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
