package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;
public class login extends JFrame implements ActionListener{
    JLabel label1,label2,label3;
    JTextField textfield1;
    JPasswordField passwordfield2;
    JButton button1,button2,button3;
    login(){
    
        super("bank management system");
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icon/bank.png"));
        Image i2=i1.getImage().getScaledInstance(100, 100,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel image =new JLabel(i3);
        image.setBounds(350,10,100,100);
        add(image);
        ImageIcon ii1=new ImageIcon(ClassLoader.getSystemResource("icon/card.png"));
        Image ii2=ii1.getImage().getScaledInstance(100, 100,Image.SCALE_DEFAULT);
        ImageIcon ii3=new ImageIcon(ii2);
        JLabel iimage =new JLabel(ii3);
        iimage.setBounds(630,350,100,100);
        add(iimage);
        label1=new JLabel("WELCOME TO ATM");
        label1.setForeground(Color.WHITE);
        label1.setFont(new Font("avantGarde",Font.BOLD,38));
        label1.setBounds(230,125,450,40);
        add(label1);
        label2=new JLabel("Card no:");
        label2.setForeground(Color.WHITE);
        label2.setFont(new Font("Ralway",Font.BOLD,28));
        label2.setBounds(150,190,375,30);
        add(label2);
        textfield1=new JTextField(15);
        textfield1.setFont(new Font("Arial",Font.BOLD,14));
        textfield1.setBounds(325,190,230,30);
        add(textfield1);
    
        label3=new JLabel("PIN: ");
        label3.setForeground(Color.WHITE);
        label3.setFont(new Font("Ralway",Font.BOLD,28));
        label3.setBounds(150,250,375,30);
        add(label3);
        passwordfield2=new JPasswordField(15);
        passwordfield2.setFont(new Font("Arial",Font.BOLD,14));
        passwordfield2.setBounds(325,250,230,30);
        add(passwordfield2);

        button1=new JButton("SIGN IN");
        button1.setFont(new Font("arial",Font.BOLD,14));
        button1.setForeground(Color.WHITE);
        button1.setBackground(Color.BLACK);
        button1.setBounds(300,300,100,30);
        button1.addActionListener(this);
        add(button1);
        button2=new JButton("CLEAR");
        button2.setFont(new Font("arial",Font.BOLD,14));
        button2.setForeground(Color.WHITE);
        button2.setBackground(Color.BLACK);
        button2.setBounds(420,300,100,30);
        button2.addActionListener(this);
        add(button2);
        button3=new JButton("SIGN UP");
        button3.setFont(new Font("arial",Font.BOLD,14));
        button3.setForeground(Color.WHITE);
        button3.setBackground(Color.BLACK);
        button3.setBounds(300,350,220,30);
        button3.addActionListener(this);
        add(button3);

        ImageIcon iii1=new ImageIcon(ClassLoader.getSystemResource("icon/backbg.png"));
        Image iii2=iii1.getImage().getScaledInstance(850, 480,Image.SCALE_DEFAULT);
        ImageIcon iii3=new ImageIcon(iii2);
        JLabel iiimage =new JLabel(iii3);
        iiimage.setBounds(0,0,850,480);
        add(iiimage); 
        

        setLayout(null);
        setSize(850,480);
        setLocation(450,200);
        setUndecorated(true);
        setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        try{
            if(e.getSource()==button1){
                Com c=new Com();
                String cardno=textfield1.getText();
                String pin=passwordfield2.getText();
                String q="select * from login where card_number ='"+cardno+"'and pin ='"+pin+"'";
                ResultSet resultSet=c.statement.executeQuery(q);
                if(resultSet.next()){
                    setVisible(false);
                    new main_class(pin);
                }else{
                    JOptionPane.showMessageDialog(null,"Incorrectn Card number or Pin");
                }



            }else if(e.getSource()==button2){
                textfield1.setText("");
                passwordfield2.setText("");
            }else if(e.getSource()==button3){
                new signup();
                setVisible(false);
            }
        }catch(Exception E){
            E.printStackTrace();
        }
    }
    public static void main(String[] args) {
        new login();
    }
    
}
